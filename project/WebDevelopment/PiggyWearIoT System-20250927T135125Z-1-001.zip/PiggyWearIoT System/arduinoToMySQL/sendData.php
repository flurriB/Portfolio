<?php
class pigCough {
    private $link = '';

    function __construct($link) {
        $this->link = $link;
    }

    function insertAccuracy($device_code, $accuracy) {
        // Get pig_id from pig_meta_data table based on device_code
        $query = "SELECT pig_id FROM pig_meta_data WHERE device_code = '".$device_code."'";
        $result = mysqli_query($this->link, $query) or die('Errant query: '.$query);
        $row = mysqli_fetch_assoc($result);

        // Check if pig_id exists
        if ($row) {
            $pig_id = $row['pig_id'];

            // Insert accuracy value into cough_events table
            $query = "INSERT INTO cough_events (pig_id, date_time, accuracy) VALUES ('".$pig_id."', NOW(), '".$accuracy."')";
            $result = mysqli_query($this->link, $query) or die('Errant query: '.$query);

            echo "Accuracy value inserted successfully!";
        } else {
            echo "Pig ID not found for the given device code!";
        }
    }
}

class pigDevice {
    public $link = '';
    public $device_code;
    public $pigCough;

    function __construct() {
        $this->connect();
        $this->pigCough = new pigCough($this->link);
    }

    function connect() {
        $this->link = mysqli_connect('localhost', 'root', '') or die('Cannot connect to the DB');
        mysqli_select_db($this->link, 'piggyweariot') or die('Cannot select the DB');
    }

    function storeInDB($device_code) {
        // Check if device_code already exists
        $query = "SELECT COUNT(*) as count FROM devices WHERE device_code = '".$device_code."'";
        $result = mysqli_query($this->link, $query) or die('Errant query: '.$query);
        $row = mysqli_fetch_assoc($result);
        $count = $row['count'];

        if ($count == 0) {
            // Insert device_code into devices table
            $query = "INSERT INTO devices (device_code) VALUES ('".$device_code."')";
            $result = mysqli_query($this->link, $query) or die('Errant query: '.$query);
            echo "Device code inserted successfully!";
        } else {
            echo "Device code already exists!";
        }

        // Set the device_code property
        $this->device_code = $device_code;
    }
}


if (isset($_GET['device_code']) && $_GET['device_code'] != '' && isset($_GET['accuracy']) && $_GET['accuracy'] != '') {
    $pigDevice = new pigDevice();
    $pigDevice->storeInDB($_GET['device_code']);

    // Access device_code
    $device_code = $pigDevice->device_code;

    // Use the $device_code variable as needed
    echo "Device code: " . $device_code;

    // Example usage of pigCough class
    $accuracy = $_GET['accuracy'];
    $pigDevice->pigCough->insertAccuracy($device_code, $accuracy);
}
?>
