-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 29, 2023 at 04:57 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `piggyweariot`
--

-- --------------------------------------------------------

--
-- Table structure for table `cough_events`
--

DROP TABLE IF EXISTS `cough_events`;
CREATE TABLE IF NOT EXISTS `cough_events` (
  `cough_id` int NOT NULL AUTO_INCREMENT,
  `pig_id` int NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `frequency` float NOT NULL,
  `duration` float NOT NULL,
  PRIMARY KEY (`cough_id`),
  KEY `pig_id` (`pig_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
CREATE TABLE IF NOT EXISTS `devices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `device_code` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `device_code`, `name`) VALUES
(1, '', 'pol'),
(2, '', 'pol'),
(3, '', 'totoy bibo');

-- --------------------------------------------------------

--
-- Table structure for table `pig_meta_data`
--

DROP TABLE IF EXISTS `pig_meta_data`;
CREATE TABLE IF NOT EXISTS `pig_meta_data` (
  `pig_id` int NOT NULL AUTO_INCREMENT,
  `pig_name` varchar(50) NOT NULL,
  `device_code` int NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pig_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pig_meta_data`
--

INSERT INTO `pig_meta_data` (`pig_id`, `pig_name`, `device_code`, `date_added`) VALUES
(24, 'nmnm', 1, '2023-05-29 16:23:57'),
(25, 'awdawd', 3, '2023-05-29 16:33:44'),
(26, 'asdasd', 3, '2023-05-29 16:35:57');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `fullName` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(128) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fullName`, `email`, `password`) VALUES
(1, 'yawa', 'jian@gmail.com', '$2b$10$NoV29n2AnqLxtIPNd7MZUOAfxN34NACResEDpMYbZORsSEG4Cr6q6');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cough_events`
--
ALTER TABLE `cough_events`
  ADD CONSTRAINT `cough_events_ibfk_1` FOREIGN KEY (`pig_id`) REFERENCES `pig_meta_data` (`pig_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
